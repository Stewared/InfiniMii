import { Buffer } from "./platform.js";
import { Decompress as ZstdDecompress } from "fzstd";

const CHAR_INFO_SIZE = 152;
const MII_BLOCK_SIZE = 4 + CHAR_INFO_SIZE;
const PERSONALITY_SIZE = 18 * 4;
const DISPLAY_NAME_SIZE = 64;
const PRONUNCIATION_SIZE = 128;
const V2_SEXUALITY_SIZE = 3;
const V3_SEXUALITY_SIZE = 4;
const V2_MARKER = new Uint8Array([0xa3, 0xa3, 0xa3]);
const V3_CANVAS_MARKER = new Uint8Array([0xa3, 0xa3, 0xa3, 0xa3]);
const V3_UGC_MARKER = new Uint8Array([0xa4, 0xa4, 0xa4, 0xa4]);
const ZSTD_MAGIC = new Uint8Array([0x28, 0xb5, 0x2f, 0xfd]);
const CANVAS_DECOMPRESSED_SIZE = 256 * 256 * 4;
const UGC_DECOMPRESSED_SIZE = 512 * 512 / 2;

const PERSONALITY_FIELDS = [
    "sociability",
    "audaciousness",
    "activeness",
    "commonsense",
    "gaiety",
    "voiceFormant",
    "voiceSpeed",
    "voiceIntonation",
    "voicePitch",
    "voiceTension",
    "voicePresetTypeHash",
    "faceGenderHash",
    "pronounTypeHash",
    "clothStyleHash",
    "birthdayYear",
    "birthdayDay",
    "birthdayDirectAge",
    "birthdayMonth"
];

const CHAR_INFO_BYTE_FIELDS = [
    "fontRegion",
    "gender",
    "height",
    "build",
    "regionMove",
    "faceFlagsRaw",
    "facelineType",
    "facelineColor",
    "wrinkleLowerType",
    "wrinkleLowerScale",
    "wrinkleLowerAspect",
    "wrinkleLowerX",
    "wrinkleLowerY",
    "wrinkleUpperType",
    "wrinkleUpperScale",
    "wrinkleUpperAspect",
    "wrinkleUpperX",
    "wrinkleUpperY",
    "makeupUpperType",
    "makeupUpperColor",
    "makeupUpperScale",
    "makeupUpperAspect",
    "makeupUpperX",
    "makeupUpperY",
    "makeupLowerType",
    "makeupLowerColor",
    "makeupLowerScale",
    "makeupLowerAspect",
    "makeupLowerX",
    "makeupLowerY"
];

const CHAR_INFO_POST_HAIR_BYTE_FIELDS = [
    "hairColorPrimary",
    "hairColorSecondary",
    "hairFrontType",
    "hairBackType",
    "hairStyleFlagsRaw",
    "earType",
    "earScale",
    "earY",
    "eyeType",
    "eyeColor",
    "eyeScale",
    "eyeAspect",
    "eyeRotate",
    "eyeX",
    "eyeY",
    "eyeShadowColor",
    "eyeHighlightType",
    "eyeHighlightScale",
    "eyeHighlightAspect",
    "eyeHighlightRotate",
    "eyeHighlightX",
    "eyeHighlightY",
    "eyelashUpperType",
    "eyelashUpperScale",
    "eyelashUpperAspect",
    "eyelashUpperRotate",
    "eyelashUpperX",
    "eyelashUpperY",
    "eyelashLowerType",
    "eyelashLowerScale",
    "eyelashLowerAspect",
    "eyelashLowerRotate",
    "eyelashLowerX",
    "eyelashLowerY",
    "eyelidUpperType",
    "eyelidUpperScale",
    "eyelidUpperAspect",
    "eyelidUpperRotate",
    "eyelidUpperX",
    "eyelidUpperY",
    "eyelidLowerType",
    "eyelidLowerScale",
    "eyelidLowerAspect",
    "eyelidLowerRotate",
    "eyelidLowerX",
    "eyelidLowerY",
    "eyebrowType",
    "eyebrowColor",
    "eyebrowScale",
    "eyebrowAspect",
    "eyebrowRotate",
    "eyebrowX",
    "eyebrowY",
    "noseType",
    "noseScale",
    "noseY",
    "mouthType",
    "mouthColor",
    "mouthScale",
    "mouthAspect",
    "mouthRotate",
    "mouthY",
    "beardType",
    "beardColor",
    "stubbleType",
    "stubbleColor",
    "mustacheType",
    "mustacheColor",
    "mustacheScale",
    "mustacheAspect",
    "mustacheY",
    "glassPrimaryType",
    "glassPrimaryColor",
    "glassScale",
    "glassAspect",
    "glassY",
    "glassLensMaterialMode",
    "glassLensColor",
    "moleScale",
    "moleX",
    "moleY",
    "schemaVersion"
];

const HASH_NAMES = new Map([
    [0x0ddcbe76, "male"],
    [0x3be5d8d4, "he"],
    [0x3b1f8b15, "female"],
    [0x25af6ee5, "she"]
]);

class LtdFormatError extends Error {
    constructor(message, code = "invalid_ltd") {
        super(message);
        this.name = "LtdFormatError";
        this.code = code;
    }
}

function asBytes(value, field = "input") {
    if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    }
    if (value instanceof ArrayBuffer || (typeof SharedArrayBuffer !== "undefined" && value instanceof SharedArrayBuffer)) {
        return new Uint8Array(value);
    }
    if (typeof value === "string" && /^(?:[0-9a-f]{2})*$/i.test(value)) {
        return Uint8Array.from(value.match(/../g) ?? [], byte => Number.parseInt(byte, 16));
    }
    // JSON.stringify(Uint8Array) produces an object with contiguous numeric keys.
    if (value && typeof value === "object" && !Array.isArray(value)) {
        const keys = Object.keys(value);
        const out = new Uint8Array(keys.length);
        for (let i = 0; i < keys.length; i++) {
            if (!Object.prototype.hasOwnProperty.call(value, String(i))) break;
            const byte = value[i];
            if (!Number.isInteger(byte) || byte < 0 || byte > 255) break;
            out[i] = byte;
            if (i === keys.length - 1) return out;
        }
        if (keys.length === 0) return out;
    }
    throw new TypeError(`${field} must be a Buffer, Uint8Array, or ArrayBuffer`);
}

function copyBytes(value, field) {
    return asBytes(value, field).slice();
}

function requireRange(bytes, offset, length, section) {
    if (!Number.isInteger(offset) || !Number.isInteger(length) || offset < 0 || length < 0 || offset + length > bytes.length) {
        const available = Math.max(0, bytes.length - offset);
        throw new LtdFormatError(`truncated ${section}: expected ${length} byte(s) at 0x${offset.toString(16)}, got ${available}`, "truncated_ltd");
    }
    return bytes.subarray(offset, offset + length);
}

function matchesAt(bytes, marker, offset) {
    if (offset < 0 || offset + marker.length > bytes.length) return false;
    for (let i = 0; i < marker.length; i++) {
        if (bytes[offset + i] !== marker[i]) return false;
    }
    return true;
}

function readU32LE(bytes, offset) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset, 4);
    return view.getUint32(0, true);
}

function readI32LE(bytes, offset) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset, 4);
    return view.getInt32(0, true);
}

function writeU32LE(bytes, offset, value) {
    new DataView(bytes.buffer, bytes.byteOffset + offset, 4).setUint32(0, value, true);
}

function writeI32LE(bytes, offset, value) {
    new DataView(bytes.buffer, bytes.byteOffset + offset, 4).setInt32(0, value, true);
}

function decodeUtf16LE(bytes) {
    let result = "";
    for (let i = 0; i + 1 < bytes.length; i += 2) {
        const codeUnit = bytes[i] | (bytes[i + 1] << 8);
        if (codeUnit === 0) break;
        result += String.fromCharCode(codeUnit);
    }
    return result;
}

function encodeUtf16LE(value, byteLength, field) {
    if (typeof value !== "string") throw new TypeError(`${field} must be a string`);
    if (value.length > byteLength / 2) {
        throw new RangeError(`${field} exceeds its ${byteLength / 2} UTF-16 code-unit field`);
    }
    const out = new Uint8Array(byteLength);
    for (let i = 0; i < value.length; i++) {
        const codeUnit = value.charCodeAt(i);
        out[i * 2] = codeUnit & 0xff;
        out[i * 2 + 1] = codeUnit >>> 8;
    }
    return out;
}

function encodePreservingText(value, originalBytes, byteLength, field) {
    if (originalBytes !== undefined) {
        const raw = asBytes(originalBytes, `${field}Bytes`);
        if (raw.length === byteLength && decodeUtf16LE(raw) === value) return raw.slice();
    }
    return encodeUtf16LE(value, byteLength, field);
}

function bytesToHex(bytes) {
    return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
}

function normalizeUuidHex(value, field = "uuidRaw") {
    if (typeof value !== "string") throw new TypeError(`${field} must be a UUID or 32-digit hex string`);
    const compact = value.replaceAll("-", "").toLowerCase();
    if (!/^[0-9a-f]{32}$/.test(compact)) throw new RangeError(`${field} must contain exactly 16 bytes`);
    return compact;
}

function formatUuid(hex) {
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function fromHex(hex, field) {
    const compact = normalizeUuidHex(hex, field);
    return Uint8Array.from(compact.match(/../g), byte => Number.parseInt(byte, 16));
}

function numeric(value, minimum, maximum, field) {
    if (!Number.isInteger(value) || value < minimum || value > maximum) {
        throw new RangeError(`${field} must be an integer from ${minimum} through ${maximum}`);
    }
    return value;
}

function booleanValue(value, field) {
    if (typeof value !== "boolean") throw new TypeError(`${field} must be a boolean`);
    return value;
}

function readLittleEndianBigInt(bytes, offset, length) {
    let result = 0n;
    for (let i = 0; i < length; i++) result |= BigInt(bytes[offset + i]) << BigInt(i * 8);
    return result;
}

function inspectZstdFrame(bytes, offset = 0) {
    requireRange(bytes, offset, 5, "Zstandard frame header");
    if (!matchesAt(bytes, ZSTD_MAGIC, offset)) {
        throw new LtdFormatError(`expected a Zstandard frame at 0x${offset.toString(16)}`, "invalid_ltd_texture");
    }

    const descriptor = bytes[offset + 4];
    if (descriptor & 0x18) {
        throw new LtdFormatError(`invalid Zstandard frame descriptor at 0x${(offset + 4).toString(16)}`, "invalid_ltd_texture");
    }
    const singleSegment = (descriptor >>> 5) & 1;
    const checksum = (descriptor >>> 2) & 1;
    if (checksum) {
        throw new LtdFormatError("checksum-bearing Zstandard frames are not supported by the LTD validator", "unsupported_ltd_texture");
    }
    const dictionaryFlag = descriptor & 3;
    if (dictionaryFlag !== 0) {
        throw new LtdFormatError("dictionary-bearing Zstandard frames are not supported by LTD", "unsupported_ltd_texture");
    }
    const contentSizeFlag = descriptor >>> 6;
    const dictionaryBytes = dictionaryFlag === 3 ? 4 : dictionaryFlag;
    const contentSizeBytes = contentSizeFlag === 0 ? singleSegment : (1 << contentSizeFlag);
    const fieldsOffset = offset + (singleSegment ? 5 : 6);
    const contentSizeOffset = fieldsOffset + dictionaryBytes;
    let cursor = contentSizeOffset + contentSizeBytes;
    requireRange(bytes, offset, cursor - offset, "Zstandard frame header");
    let contentSize = contentSizeBytes ? readLittleEndianBigInt(bytes, contentSizeOffset, contentSizeBytes) : null;
    if (contentSizeFlag === 1) contentSize += 256n;
    let windowSize = contentSize;
    if (!singleSegment) {
        const windowDescriptor = bytes[offset + 5];
        const base = 1n << BigInt(10 + (windowDescriptor >>> 3));
        windowSize = base + (base >> 3n) * BigInt(windowDescriptor & 7);
    }
    const maximumBlockSize = Number(windowSize < 131072n ? windowSize : 131072n);

    let last = false;
    while (!last) {
        const header = requireRange(bytes, cursor, 3, "Zstandard block header");
        const packed = header[0] | (header[1] << 8) | (header[2] << 16);
        last = (packed & 1) !== 0;
        const blockType = (packed >>> 1) & 3;
        const blockSize = packed >>> 3;
        if (blockType === 3 || blockSize > maximumBlockSize) {
            throw new LtdFormatError(`invalid Zstandard block at 0x${cursor.toString(16)}`, "invalid_ltd_texture");
        }
        cursor += 3;
        const encodedSize = blockType === 1 ? 1 : blockSize;
        requireRange(bytes, cursor, encodedSize, "Zstandard block payload");
        cursor += encodedSize;
    }
    if (checksum) {
        requireRange(bytes, cursor, 4, "Zstandard content checksum");
        cursor += 4;
    }
    return { byteLength: cursor - offset, contentSize, windowSize };
}

/** Return the encoded size of exactly one ordinary Zstandard frame. */
function zstdFrameByteLength(bytes, offset = 0) {
    return inspectZstdFrame(bytes, offset).byteLength;
}

function validateTexturePayload(payload, declaredPresent, section, expectedDecodedSize) {
    if (!declaredPresent) {
        if (payload.length !== 0) {
            throw new LtdFormatError(`${section} payload is present while its header flag is false`, "invalid_ltd_texture");
        }
        return;
    }
    const frame = inspectZstdFrame(payload, 0);
    if (frame.byteLength !== payload.length) {
        throw new LtdFormatError(`${section} must contain exactly one Zstandard frame`, "invalid_ltd_texture");
    }
    const expectedSize = BigInt(expectedDecodedSize);
    if (frame.contentSize === null || frame.contentSize !== expectedSize) {
        const declared = frame.contentSize === null ? "no decoded size" : `${frame.contentSize} decoded bytes`;
        throw new LtdFormatError(`${section} declares ${declared}; expected ${expectedDecodedSize}`, "invalid_ltd_texture");
    }
    if (frame.windowSize !== null && frame.windowSize > expectedSize) {
        throw new LtdFormatError(`${section} declares a Zstandard window larger than its ${expectedDecodedSize}-byte surface`, "invalid_ltd_texture");
    }
    let decodedLength = 0;
    try {
        const decoder = new ZstdDecompress(chunk => {
            decodedLength += chunk.length;
            if (decodedLength > expectedDecodedSize) {
                throw new LtdFormatError(`${section} expands beyond its ${expectedDecodedSize}-byte surface`, "invalid_ltd_texture");
            }
        });
        decoder.push(payload, true);
    } catch (error) {
        if (error instanceof LtdFormatError) throw error;
        throw new LtdFormatError(`${section} contains an invalid Zstandard frame: ${error.message}`, "invalid_ltd_texture");
    }
    if (decodedLength !== expectedDecodedSize) {
        throw new LtdFormatError(`${section} must decode to ${expectedDecodedSize} bytes, got ${decodedLength}`, "invalid_ltd_texture");
    }
}

function parseCharInfoEx(value) {
    const bytes = asBytes(value, "CharInfoEx");
    if (bytes.length !== CHAR_INFO_SIZE) {
        throw new LtdFormatError(`CharInfoEx must be ${CHAR_INFO_SIZE} bytes, got ${bytes.length}`, "invalid_ltd_char_info");
    }
    const uuidRaw = bytesToHex(bytes.subarray(0, 16));
    const nameBytes = bytes.slice(16, 38);
    const result = {
        uuidRaw,
        uuid: formatUuid(uuidRaw),
        name: decodeUtf16LE(nameBytes),
        nameBytes
    };
    let cursor = 38;
    for (const field of CHAR_INFO_BYTE_FIELDS) result[field] = bytes[cursor++];
    result.hairType = bytes[cursor] | (bytes[cursor + 1] << 8);
    cursor += 2;
    for (const field of CHAR_INFO_POST_HAIR_BYTE_FIELDS) result[field] = bytes[cursor++];
    if (cursor !== CHAR_INFO_SIZE) throw new Error(`internal CharInfoEx layout error: ${cursor}`);

    const faceFlags = result.faceFlagsRaw;
    result.faceFlags = {
        specialMii: Boolean(faceFlags & 0x01),
        bangsSide: Boolean(faceFlags & 0x02),
        backDualColor: Boolean(faceFlags & 0x04),
        bangsDualColor: Boolean(faceFlags & 0x08),
        eyeShadowEnabled: Boolean(faceFlags & 0x10),
        mouthInverted: Boolean(faceFlags & 0x20),
        mustacheInverted: Boolean(faceFlags & 0x40),
        moleEnabled: Boolean(faceFlags & 0x80)
    };
    const hairFlags = result.hairStyleFlagsRaw;
    result.hairStyleFlags = {
        leftSide: Boolean(hairFlags & 0x01),
        rightSide: Boolean(hairFlags & 0x02),
        reserved: hairFlags >>> 2
    };
    return result;
}

function encodeCharInfoEx(charInfo) {
    if (!charInfo || typeof charInfo !== "object") throw new TypeError("ltd.charInfo is required");
    const out = new Uint8Array(CHAR_INFO_SIZE);
    const uuidRaw = normalizeUuidHex(charInfo.uuidRaw ?? charInfo.uuid, "ltd.charInfo.uuidRaw");
    out.set(fromHex(uuidRaw, "ltd.charInfo.uuidRaw"), 0);
    out.set(encodePreservingText(charInfo.name, charInfo.nameBytes, 22, "ltd.charInfo.name"), 16);

    const source = charInfo;
    let cursor = 38;
    for (const field of CHAR_INFO_BYTE_FIELDS) out[cursor++] = numeric(source[field], 0, 255, `ltd.charInfo.${field}`);
    const hairType = numeric(source.hairType, 0, 65535, "ltd.charInfo.hairType");
    out[cursor++] = hairType & 0xff;
    out[cursor++] = hairType >>> 8;
    for (const field of CHAR_INFO_POST_HAIR_BYTE_FIELDS) out[cursor++] = numeric(source[field], 0, 255, `ltd.charInfo.${field}`);
    return out;
}

function parsePersonality(bytes) {
    const result = {};
    for (let i = 0; i < PERSONALITY_FIELDS.length; i++) {
        result[PERSONALITY_FIELDS[i]] = readI32LE(bytes, i * 4);
    }
    result.voicePresetType = HASH_NAMES.get(result.voicePresetTypeHash) ?? null;
    result.faceGender = HASH_NAMES.get(result.faceGenderHash) ?? null;
    result.pronounType = HASH_NAMES.get(result.pronounTypeHash) ?? null;
    result.clothStyle = HASH_NAMES.get(result.clothStyleHash) ?? null;
    return result;
}

function encodePersonality(personality) {
    if (!personality || typeof personality !== "object") throw new TypeError("ltd.personalityAndVoice is required");
    const out = new Uint8Array(PERSONALITY_SIZE);
    for (let i = 0; i < PERSONALITY_FIELDS.length; i++) {
        const field = PERSONALITY_FIELDS[i];
        const value = numeric(personality[field], -2147483648, 2147483647, `ltd.personalityAndVoice.${field}`);
        writeI32LE(out, i * 4, value);
    }
    return out;
}

function payloadRecord(payload, offset, declaredPresent) {
    return {
        offset,
        byteLength: payload.length,
        declaredPresent,
        compression: payload.length && matchesAt(payload, ZSTD_MAGIC, 0) ? "zstandard" : null,
        data: payload.slice()
    };
}

function section(offset, byteLength) {
    return { offset, byteLength };
}

function parseLtdContainer(value) {
    const bytes = asBytes(value);
    if (bytes.length < 1) throw new LtdFormatError("file is too short to contain an LTD header", "truncated_ltd");
    const originalVersion = bytes[0];
    if (originalVersion !== 2 && originalVersion !== 3) {
        throw new LtdFormatError(`only LTD ShareMii versions 2 and 3 are supported, got ${originalVersion}`, "unsupported_ltd_version");
    }

    const v2 = originalVersion === 2;
    const headerSize = v2 ? 5 : 4;
    const headerBytes = requireRange(bytes, 0, headerSize, `LTD v${originalVersion} header`);
    if (headerBytes[1] > 1 || headerBytes[2] > 1) {
        throw new LtdFormatError("LTD texture-presence flags must each be 0 or 1", "invalid_ltd_header");
    }
    const hasCanvas = headerBytes[1] !== 0;
    const hasUgcTexture = headerBytes[2] !== 0;
    const reserved = headerBytes[3];
    const legacyPadding = v2 ? headerBytes[4] : undefined;
    const miiBlockOffset = headerSize;
    const miiBlock = requireRange(bytes, miiBlockOffset, MII_BLOCK_SIZE, "LTD Mii block");
    const charInfoLength = readU32LE(miiBlock, 0);
    if (charInfoLength !== CHAR_INFO_SIZE) {
        throw new LtdFormatError(`expected CharInfoEx length ${CHAR_INFO_SIZE}, got ${charInfoLength}`, "invalid_ltd_char_info");
    }

    let cursor = miiBlockOffset + 4;
    const charInfoOffset = cursor;
    const charInfoBytes = requireRange(bytes, cursor, charInfoLength, "CharInfoEx");
    cursor += charInfoLength;
    const personalityOffset = cursor;
    const personalityBytes = requireRange(bytes, cursor, PERSONALITY_SIZE, "personality and voice block");
    cursor += PERSONALITY_SIZE;
    const displayNameOffset = cursor;
    const displayNameBytes = requireRange(bytes, cursor, DISPLAY_NAME_SIZE, "display name").slice();
    cursor += DISPLAY_NAME_SIZE;
    const pronunciationOffset = cursor;
    const pronunciationBytes = requireRange(bytes, cursor, PRONUNCIATION_SIZE, "pronunciation").slice();
    cursor += PRONUNCIATION_SIZE;
    const sexualitySize = v2 ? V2_SEXUALITY_SIZE : V3_SEXUALITY_SIZE;
    const sexualityOffset = cursor;
    const sexualityBytes = requireRange(bytes, cursor, sexualitySize, "sexuality block").slice();
    cursor += sexualitySize;

    const canvasMarkerOffset = cursor;
    let canvasMarker;
    let canvasPayloadOffset;
    let canvasPayload;
    let ugcMarkerOffset;
    let ugcMarker;
    if (v2) {
        canvasMarker = requireRange(bytes, cursor, V2_MARKER.length, "v2 canvas marker");
        if (!matchesAt(canvasMarker, V2_MARKER, 0)) {
            throw new LtdFormatError(`expected LTD v2 canvas marker at 0x${cursor.toString(16)}`, "missing_ltd_marker");
        }
        canvasPayloadOffset = cursor + V2_MARKER.length;
        const canvasLength = hasCanvas ? zstdFrameByteLength(bytes, canvasPayloadOffset) : 0;
        ugcMarkerOffset = canvasPayloadOffset + canvasLength;
        ugcMarker = requireRange(bytes, ugcMarkerOffset, V2_MARKER.length, "v2 UGC texture marker");
        if (!matchesAt(ugcMarker, V2_MARKER, 0)) {
            throw new LtdFormatError(`expected LTD v2 UGC marker immediately after the canvas frame at 0x${ugcMarkerOffset.toString(16)}`, "missing_ltd_marker");
        }
        canvasPayload = bytes.subarray(canvasPayloadOffset, ugcMarkerOffset);
    } else {
        canvasMarker = requireRange(bytes, cursor, V3_CANVAS_MARKER.length, "v3 canvas marker");
        if (!matchesAt(canvasMarker, V3_CANVAS_MARKER, 0)) {
            throw new LtdFormatError(`expected LTD v3 canvas marker at 0x${cursor.toString(16)}`, "missing_ltd_marker");
        }
        canvasPayloadOffset = cursor + V3_CANVAS_MARKER.length;
        const canvasLength = hasCanvas ? zstdFrameByteLength(bytes, canvasPayloadOffset) : 0;
        ugcMarkerOffset = canvasPayloadOffset + canvasLength;
        ugcMarker = requireRange(bytes, ugcMarkerOffset, V3_UGC_MARKER.length, "v3 UGC texture marker");
        if (!matchesAt(ugcMarker, V3_UGC_MARKER, 0)) {
            throw new LtdFormatError(`expected LTD v3 UGC marker immediately after the canvas frame at 0x${ugcMarkerOffset.toString(16)}`, "missing_ltd_marker");
        }
        canvasPayload = bytes.subarray(canvasPayloadOffset, ugcMarkerOffset);
    }

    const ugcPayloadOffset = ugcMarkerOffset + ugcMarker.length;
    const ugcPayload = bytes.subarray(ugcPayloadOffset);
    validateTexturePayload(canvasPayload, hasCanvas, "canvas texture", CANVAS_DECOMPRESSED_SIZE);
    validateTexturePayload(ugcPayload, hasUgcTexture, "UGC texture", UGC_DECOMPRESSED_SIZE);

    const charInfo = parseCharInfoEx(charInfoBytes);
    const personalityAndVoice = parsePersonality(personalityBytes);
    const displayName = decodeUtf16LE(displayNameBytes);
    const pronunciation = decodeUtf16LE(pronunciationBytes);
    const loveGenderRaw = Array.from(sexualityBytes);
    const loveGender = {
        male: Boolean(sexualityBytes[0]),
        female: Boolean(sexualityBytes[1]),
        third: Boolean(sexualityBytes[2]),
        raw: loveGenderRaw.slice(),
        sourceRaw: loveGenderRaw,
        serializedLength: sexualitySize
    };
    if (!v2) loveGender.uninterpretedFourthByte = sexualityBytes[3];

    return {
        format: "Tomodachi Life: Living the Dream ShareMii",
        version: originalVersion,
        originalVersion,
        byteLength: bytes.length,
        header: {
            version: originalVersion,
            hasCanvas,
            hasUgcTexture,
            reserved,
            charInfoLength,
            ...(v2 ? { legacyPadding } : {})
        },
        charInfo,
        personalityAndVoice,
        displayName,
        displayNameBytes,
        pronunciation,
        pronunciationBytes,
        loveGender,
        canvasMarker: bytesToHex(canvasMarker),
        ugcTextureMarker: bytesToHex(ugcMarker),
        canvasTexturePayload: payloadRecord(canvasPayload, canvasPayloadOffset, hasCanvas),
        ugcTexturePayload: payloadRecord(ugcPayload, ugcPayloadOffset, hasUgcTexture),
        serializedSections: {
            formatHeader: section(0, headerSize),
            miiBlock: section(miiBlockOffset, MII_BLOCK_SIZE),
            charInfo: section(charInfoOffset, charInfoLength),
            personalityAndVoice: section(personalityOffset, PERSONALITY_SIZE),
            displayName: section(displayNameOffset, DISPLAY_NAME_SIZE),
            pronunciation: section(pronunciationOffset, PRONUNCIATION_SIZE),
            sexuality: section(sexualityOffset, sexualitySize),
            canvasMarker: section(canvasMarkerOffset, canvasMarker.length),
            canvasTexturePayload: section(canvasPayloadOffset, canvasPayload.length),
            ugcTextureMarker: section(ugcMarkerOffset, ugcMarker.length),
            ugcTexturePayload: section(ugcPayloadOffset, ugcPayload.length)
        }
    };
}

/** Decode an LTD ShareMii v2/v3 file into a MiiJS-compatible object. */
function decodeLtdMii(value) {
    const ltd = parseLtdContainer(value);
    ltd.canonicalProjection = {
        name: ltd.displayName,
        miiId: ltd.charInfo.uuidRaw,
        type: ltd.charInfo.faceFlagsRaw & 1 ? "Special" : "Default",
        gender: ltd.charInfo.gender,
        height: ltd.charInfo.height,
        weight: ltd.charInfo.build
    };
    const meta = {};
    Object.defineProperties(meta, {
        name: {
            enumerable: true,
            get: () => ltd.displayName,
            set: value => { ltd.displayName = value; }
        },
        miiId: {
            enumerable: true,
            get: () => ltd.charInfo.uuidRaw.toUpperCase(),
            set: value => {
                const uuidRaw = normalizeUuidHex(value, "meta.miiId");
                ltd.charInfo.uuidRaw = uuidRaw;
                ltd.charInfo.uuid = formatUuid(uuidRaw);
            }
        },
        type: {
            enumerable: true,
            get: () => ltd.charInfo.faceFlagsRaw & 1 ? "Special" : "Default",
            set: value => {
                if (value !== "Special" && value !== "Default") throw new RangeError("meta.type must be Special or Default for LTD data");
                ltd.charInfo.faceFlagsRaw = value === "Special"
                    ? ltd.charInfo.faceFlagsRaw | 1
                    : ltd.charInfo.faceFlagsRaw & 0xfe;
                ltd.charInfo.faceFlags.specialMii = value === "Special";
            }
        }
    });
    const general = {};
    for (const [canonicalField, ltdField] of [["gender", "gender"], ["height", "height"], ["weight", "build"]]) {
        Object.defineProperty(general, canonicalField, {
            enumerable: true,
            get: () => ltd.charInfo[ltdField],
            set: value => { ltd.charInfo[ltdField] = value; }
        });
    }
    return { meta, general, ltd };
}

function reconcileProjectionField({ baseline, canonical, current, field, normalize = value => value, apply }) {
    if (canonical === undefined) return;
    const normalizedBaseline = normalize(baseline);
    const normalizedCanonical = normalize(canonical);
    const normalizedCurrent = normalize(current);
    const canonicalChanged = normalizedCanonical !== normalizedBaseline;
    const ltdChanged = normalizedCurrent !== normalizedBaseline;
    if (canonicalChanged && ltdChanged && normalizedCanonical !== normalizedCurrent) {
        throw new LtdFormatError(`conflicting edits to ${field} and its ltd source field`, "conflicting_ltd_edit");
    }
    if (canonicalChanged) apply(canonical);
}

function reconcileCanonicalProjection(source, ltd) {
    const baseline = ltd.canonicalProjection;
    if (!baseline || !source?.ltd) return;
    reconcileProjectionField({
        baseline: baseline.name,
        canonical: source.meta?.name,
        current: ltd.displayName,
        field: "meta.name",
        apply: value => { ltd.displayName = value; }
    });
    reconcileProjectionField({
        baseline: baseline.miiId,
        canonical: source.meta?.miiId,
        current: ltd.charInfo.uuidRaw,
        field: "meta.miiId",
        normalize: value => normalizeUuidHex(value, "meta.miiId"),
        apply: value => {
            const uuidRaw = normalizeUuidHex(value, "meta.miiId");
            ltd.charInfo.uuidRaw = uuidRaw;
            ltd.charInfo.uuid = formatUuid(uuidRaw);
        }
    });
    reconcileProjectionField({
        baseline: baseline.type,
        canonical: source.meta?.type,
        current: ltd.charInfo.faceFlagsRaw & 1 ? "Special" : "Default",
        field: "meta.type",
        apply: value => {
            if (value !== "Special" && value !== "Default") throw new RangeError("meta.type must be Special or Default for LTD data");
            ltd.charInfo.faceFlagsRaw = value === "Special"
                ? ltd.charInfo.faceFlagsRaw | 1
                : ltd.charInfo.faceFlagsRaw & 0xfe;
        }
    });
    for (const [canonicalField, ltdField] of [["gender", "gender"], ["height", "height"], ["weight", "build"]]) {
        reconcileProjectionField({
            baseline: baseline[canonicalField],
            canonical: source.general?.[canonicalField],
            current: ltd.charInfo[ltdField],
            field: `general.${canonicalField}`,
            apply: value => { ltd.charInfo[ltdField] = value; }
        });
    }
}

function encodeLoveGender(loveGender, version) {
    if (!loveGender || typeof loveGender !== "object") throw new TypeError("ltd.loveGender is required");
    const length = version === 2 ? V2_SEXUALITY_SIZE : V3_SEXUALITY_SIZE;
    if (loveGender.raw === undefined) throw new TypeError("ltd.loveGender.raw is required");
    if (loveGender.sourceRaw === undefined) throw new TypeError("ltd.loveGender.sourceRaw is required for edit reconciliation");
    if (!Array.isArray(loveGender.raw) && !ArrayBuffer.isView(loveGender.raw)) {
        throw new TypeError("ltd.loveGender.raw must be an array or typed array");
    }
    if (!Array.isArray(loveGender.sourceRaw) && !ArrayBuffer.isView(loveGender.sourceRaw)) {
        throw new TypeError("ltd.loveGender.sourceRaw must be an array or typed array");
    }
    const rawValues = Array.from(loveGender.raw);
    const sourceRaw = Array.from(loveGender.sourceRaw);
    if (rawValues.length !== length) throw new RangeError(`ltd.loveGender.raw must contain ${length} bytes for LTD v${version}`);
    if (sourceRaw.length !== length) throw new RangeError(`ltd.loveGender.sourceRaw must contain ${length} bytes for LTD v${version}`);
    for (let i = 0; i < rawValues.length; i++) numeric(rawValues[i], 0, 255, `ltd.loveGender.raw[${i}]`);
    for (let i = 0; i < sourceRaw.length; i++) numeric(sourceRaw[i], 0, 255, `ltd.loveGender.sourceRaw[${i}]`);
    const out = Uint8Array.from(rawValues);
    const fields = ["male", "female", "third"];
    for (let i = 0; i < fields.length; i++) {
        const field = fields[i];
        if (loveGender[field] !== undefined) {
            const requested = booleanValue(loveGender[field], `ltd.loveGender.${field}`);
            const rawChanged = rawValues[i] !== sourceRaw[i];
            const aliasChanged = requested !== Boolean(sourceRaw[i]);
            if (rawChanged && aliasChanged && Boolean(rawValues[i]) !== requested) {
                throw new LtdFormatError(`conflicting edits to ltd.loveGender.raw[${i}] and ltd.loveGender.${field}`, "conflicting_ltd_edit");
            }
            if (aliasChanged && !rawChanged) out[i] = requested ? 1 : 0;
        }
    }
    if (version === 3 && loveGender.uninterpretedFourthByte !== undefined) {
        const requested = numeric(loveGender.uninterpretedFourthByte, 0, 255, "ltd.loveGender.uninterpretedFourthByte");
        const rawChanged = rawValues[3] !== sourceRaw[3];
        const aliasChanged = requested !== sourceRaw[3];
        if (rawChanged && aliasChanged && rawValues[3] !== requested) {
            throw new LtdFormatError("conflicting edits to ltd.loveGender.raw[3] and ltd.loveGender.uninterpretedFourthByte", "conflicting_ltd_edit");
        }
        if (aliasChanged && !rawChanged) out[3] = requested;
    }
    return out;
}

function concatBytes(parts) {
    const total = parts.reduce((sum, part) => sum + part.length, 0);
    const out = new Uint8Array(total);
    let cursor = 0;
    for (const part of parts) {
        out.set(part, cursor);
        cursor += part.length;
    }
    return out;
}

/** Encode a decoded LTD object while preserving its original v2 or v3 wire version. */
function encodeLtdMii(value) {
    const source = structuredClone(value?.fields ?? value);
    const ltd = source?.ltd ?? source;
    if (!ltd || typeof ltd !== "object") throw new TypeError("encoding LTD requires a decoded object with an ltd namespace");
    reconcileCanonicalProjection(source, ltd);
    const version = ltd.originalVersion;
    if (version !== 2 && version !== 3) throw new LtdFormatError(`only LTD ShareMii versions 2 and 3 are supported, got ${version}`, "unsupported_ltd_version");
    if ((ltd.version !== undefined && ltd.version !== version) || (ltd.header?.version !== undefined && ltd.header.version !== version)) {
        throw new LtdFormatError("LTD wire-version conversion is not supported; version and header.version must match originalVersion", "unsupported_ltd_version");
    }
    const header = ltd.header ?? {};
    const hasCanvas = booleanValue(header.hasCanvas, "ltd.header.hasCanvas");
    const hasUgcTexture = booleanValue(header.hasUgcTexture, "ltd.header.hasUgcTexture");
    const headerBytes = version === 2 ? new Uint8Array(5) : new Uint8Array(4);
    headerBytes[0] = version;
    headerBytes[1] = hasCanvas ? 1 : 0;
    headerBytes[2] = hasUgcTexture ? 1 : 0;
    if (header.charInfoLength !== undefined && header.charInfoLength !== CHAR_INFO_SIZE) {
        throw new LtdFormatError(`ltd.header.charInfoLength must remain ${CHAR_INFO_SIZE}`, "invalid_ltd_char_info");
    }
    headerBytes[3] = numeric(header.reserved, 0, 255, "ltd.header.reserved");
    if (version === 2) headerBytes[4] = numeric(header.legacyPadding, 0, 255, "ltd.header.legacyPadding");

    const charInfoBytes = encodeCharInfoEx(ltd.charInfo);
    const miiBlock = new Uint8Array(MII_BLOCK_SIZE);
    writeU32LE(miiBlock, 0, CHAR_INFO_SIZE);
    miiBlock.set(charInfoBytes, 4);
    const personalityBytes = encodePersonality(ltd.personalityAndVoice);
    const displayNameBytes = encodePreservingText(ltd.displayName, ltd.displayNameBytes, DISPLAY_NAME_SIZE, "ltd.displayName");
    const pronunciationBytes = encodePreservingText(ltd.pronunciation, ltd.pronunciationBytes, PRONUNCIATION_SIZE, "ltd.pronunciation");
    const sexualityBytes = encodeLoveGender(ltd.loveGender, version);
    if (ltd.canvasTexturePayload?.data === undefined || ltd.ugcTexturePayload?.data === undefined) {
        throw new TypeError("both LTD texture payload data fields are required, including empty payloads");
    }
    const canvasPayload = copyBytes(ltd.canvasTexturePayload.data, "ltd.canvasTexturePayload.data");
    const ugcPayload = copyBytes(ltd.ugcTexturePayload.data, "ltd.ugcTexturePayload.data");
    validateTexturePayload(canvasPayload, hasCanvas, "canvas texture", CANVAS_DECOMPRESSED_SIZE);
    validateTexturePayload(ugcPayload, hasUgcTexture, "UGC texture", UGC_DECOMPRESSED_SIZE);
    const canvasMarker = version === 2 ? V2_MARKER : V3_CANVAS_MARKER;
    const ugcMarker = version === 2 ? V2_MARKER : V3_UGC_MARKER;
    const encoded = concatBytes([
        headerBytes,
        miiBlock,
        personalityBytes,
        displayNameBytes,
        pronunciationBytes,
        sexualityBytes,
        canvasMarker,
        canvasPayload,
        ugcMarker,
        ugcPayload
    ]);
    parseLtdContainer(encoded);
    return Buffer.from(encoded);
}

/** Structural predicate used by automatic format detection. */
function isLtdMii(value) {
    try {
        parseLtdContainer(value);
        return true;
    } catch {
        return false;
    }
}

export {
    CHAR_INFO_SIZE,
    LtdFormatError,
    decodeLtdMii,
    encodeLtdMii,
    isLtdMii,
    parseCharInfoEx,
    parseLtdContainer,
    zstdFrameByteLength
};
